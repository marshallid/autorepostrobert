const Client = require('instagram-private-api').V1;
const delay = require('delay');
const chalk = require('chalk');
const rp = require('request-promise');
const inquirer = require('inquirer');
const download = require('download');
const fs = require('async-file');

const User = [
	{
		type:'input',
		name:'username',
		message:'Insert Username',
		validate: function(value){
			if(!value) return 'Can\'t Empty';
			return true;
		}
	},
	{
		type:'password',
		name:'password',
		message:'Insert Password',
		mask:'*',
		validate: function(value){
			if(!value) return 'Can\'t Empty';
			return true;
		}
	},
	{
		type:'input',
		name:'target',
		message:'Insert Username Target (Without @[at])',
		validate: function(value){
			if(!value) return 'Can\'t Empty';
			return true;
		}
	},
	{
		type:'input',
		name:'sleep',
		message:'Insert Sleep (In MiliSeconds)',
		validate: function(value){
			value = value.match(/[0-9]/);
			if (value) return true;
			return 'Delay is number';
		}
	}
]

const Login = async function(User){

    const Device = new Client.Device(User.username);
    const Storage = new Client.CookieMemoryStorage();
    const session = new Client.Session(Device, Storage);

    try {
        await Client.Session.create(Device, Storage, User.username, User.password)
        const account = await session.getAccount();
        return Promise.resolve({session,account});
    } catch (err) {
        return Promise.reject(err);
    }

}

const Target = async function(username){
	
	const url = 'https://www.instagram.com/'+username+'/?__a=1'
	const option = {
		url: url,
		method: 'GET',
		json:true
	}
	try{
		const account = await rp(option);
		if (account.user.is_private) {
			return Promise.reject('Target is private Account');
		} else {
			const id = account.user.id;
			const followers = account.user.followed_by.count;
			return Promise.resolve({id,followers});			
		}
	} catch (err){
		return Promise.reject(err);
	}

}

const UploadVideo = async function(session, poto){

	try{
		await download(poto.params.images[0].url, 'Media', {filename:poto.params.id+'.jpg'})
		await download(poto.params.videos[0].url, 'Media', {filename:poto.params.id+'.mp4'})
		var doUpload = await Client.Upload.video(session, './Media/'+poto.params.id+'.mp4', './Media/'+poto.params.id+'.jpg');
		doUpload = await  Client.Media.configureVideo(session, doUpload.uploadId, poto.params.caption, doUpload.durationms);
		console.log(chalk`{bold.cyan ${poto.params.id}} => {bold.cyan ${doUpload.params.id}} [{green ${doUpload.params.webLink}}] {bold.green UPLOADED}`)
		fs.unlink('./Media/'+poto.params.id+'.jpg');
		fs.unlink('./Media/'+poto.params.id+'.mp4');
	} catch(e){
		console.log(`[{bold.cyan ${poto.params.id}}] => {bold.red ${e}}`)
	}

}

const UploadFoto = async function(session, poto){

	try{
		await download(poto.params.images[0].url, 'Media', {filename:poto.params.id+'.jpg'})
		var doUpload = await Client.Upload.photo(session, './Media/'+poto.params.id+'.jpg');
		doUpload = await Client.Media.configurePhoto(session, doUpload.params.uploadId, poto.params.caption);
		console.log(chalk`{bold.cyan ${poto.params.id}} => {bold.cyan ${doUpload.params.id}} [{green ${doUpload.params.webLink}}] {bold.green UPLOADED}`)
		fs.unlink('./Media/'+poto.params.id+'.jpg');
	} catch(e) {
		console.log(`[{bold.cyan ${poto.params.id}}] => {bold.red ${e}}`)
	}

}

const Excute = async function(User,TargetUsername,sleep){

	try {

		console.log(`\n[+] Try Login ....`)
		const doLogin = await Login(User);
		console.log(`[+] Try Get Id ....`)
		const getTarget = await Target(TargetUsername);
		console.log(`[+] Try Repost the feed .... \n`)
		const Media = new Client.Feed.UserMedia(doLogin.session, getTarget.id);
		var cursor;
		do {
			if (cursor) Media.setCursor(cursor);
			var getPoto = await Media.get();
			for (let i = 0; i < getPoto.length; i++) {
				switch(getPoto[i].params.mediaType){
					case 1:
						await UploadFoto(doLogin.session,getPoto[i])
						break;
					case 2:
						await UploadVideo(doLogin.session,getPoto[i])
						break;
					default:
				}					
				await delay(sleep);
			}
			cursor = await Media.getCursor()
		} while (Media.isMoreAvailable());
	} catch (e) {
		console.log(e);
	}

}

console.log(chalk`
{bold Instagram Auto Repost Media Target}
{green BC0DE.NET - NAONLAH.NET - WingKocoli}
{bold.red Code By Ccocot | ccocot@bc0de.net}
`);

inquirer.prompt(User)
	.then(answers => {
		Excute({
			username:answers.username,
			password:answers.password
		},answers.target,answers.sleep);
	})